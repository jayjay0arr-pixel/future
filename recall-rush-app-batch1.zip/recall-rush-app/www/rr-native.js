/* Recall Rush native layer (Android via Capacitor).
   - first launch: creates Documents/RecallRush/{ESAS,MATH,EE}
   - keeps Documents/RecallRush/recall-rush-data.json in sync with the app
   - drives the sync status chip in the header
   - Android back button
   Also works in a plain browser: it just skips the native parts. */
(function () {
  "use strict";
  var TK = "ff_topics_v2", PK = "ff_progress_v1";
  var ROOT = "RecallRush", FILE = ROOT + "/recall-rush-data.json", CATS = ["ESAS", "MATH", "EE"];

  var cap = window.Capacitor || null, native = false;
  try { native = !!(cap && cap.isNativePlatform && cap.isNativePlatform()); } catch (e) {}
  var plug = (cap && cap.Plugins) || {};
  var FS = native ? plug.Filesystem : null;
  var APP = native ? plug.App : null;

  var rawSet = Storage.prototype.setItem, rawGet = Storage.prototype.getItem;
  var dir = null, timer = 0, busy = false, again = false, last = "";

  /* ---------- status chip ---------- */
  function status(st, short, path, title) {
    var b = document.getElementById("sv");
    if (!b) return;
    b.setAttribute("data-st", st);
    var t = document.getElementById("svt"), p = document.getElementById("svp");
    if (t) t.textContent = short;
    if (p) p.textContent = path || "";
    b.title = title || "";
  }
  function showOk() {
    if (dir === "DOCUMENTS") status("ok", "Synced", " to Documents/RecallRush", "Saved to Documents/RecallRush/recall-rush-data.json. Tap to sync now.");
    else status("warn", "Saved in app only", "", "The Documents folder wasn't available, so your data is in the app's private storage. Tap to retry.");
  }
  function showErr(e) {
    status("err", "Not synced", "", "Couldn't write the data file: " + String((e && e.message) || e) + ". Tap to retry.");
  }

  /* ---------- helpers ---------- */
  function readLS(k) { try { return JSON.parse(rawGet.call(window.localStorage, k) || "null"); } catch (e) { return null; } }

  function build() {
    var T = readLS(TK) || {}, Pr = readLS(PK);
    var o = { v: 1, t: T.t || [], f: T.f || [], c: T.c || {}, r: T.r || {}, l: T.l || "medium", s: T.s || 0 };
    if (Pr) o.p = Pr;
    o.ts = Math.max(T.ts || 0, (Pr && Pr.ts) || 0) || Date.now();
    return JSON.stringify(o);
  }

  async function ensure(d) {
    for (var i = 0; i < CATS.length; i++) {
      try { await FS.mkdir({ path: ROOT + "/" + CATS[i], directory: d, recursive: true }); }
      catch (e) { if (!/exist/i.test(String((e && e.message) || e))) throw e; }
    }
  }
  async function readFile(d) {
    try {
      var r = await FS.readFile({ path: FILE, directory: d, encoding: "utf8" });
      return typeof r.data === "string" ? r.data : null;
    } catch (e) { return null; }
  }
  function writeTo(d, str) {
    return FS.writeFile({ path: FILE, data: str, directory: d, encoding: "utf8", recursive: true });
  }

  /* ---------- sync ---------- */
  function hasData(str) {
    try { var j = JSON.parse(str); return !!((j.t && j.t.length) || (j.f && j.f.length) || (j.p && j.p.xp > 0)); }
    catch (e) { return false; }
  }
  var fileHasData = false;   // the data file on disk currently holds real content

  async function flush(force) {
    if (!FS || !dir) return;
    clearTimeout(timer);
    if (busy) { again = true; return; }
    /* Safety: if the app's own storage has been wiped (no topics key at all) but the file still
       holds your data, never overwrite the file with an empty copy. */
    if (!readLS(TK) && fileHasData) return;
    var str = build();
    if (!force && str === last) return;
    busy = true;
    try {
      try { await writeTo(dir, str); }
      catch (e) {
        if (dir !== "DOCUMENTS") throw e;
        dir = "DATA";                      // fall back to the app's private folder
        await ensure("DATA");
        await writeTo("DATA", str);
      }
      last = str;
      fileHasData = hasData(str);
      showOk();
    } catch (e) { showErr(e); }
    busy = false;
    if (again) { again = false; schedule(); }
  }
  function schedule() { clearTimeout(timer); timer = setTimeout(function () { flush(false); }, 700); }

  /* when the app saves, mirror it to the file */
  Storage.prototype.setItem = function (k, v) {
    rawSet.call(this, k, v);
    if (FS && this === window.localStorage && (k === TK || k === PK)) schedule();
  };

  function seed(txt) {
    var j;
    try { j = JSON.parse(txt); } catch (e) { return; }
    if (!j || !Array.isArray(j.t)) return;
    var T = readLS(TK);
    if (!T || (j.ts || 0) > (T.ts || 0)) {
      rawSet.call(window.localStorage, TK, JSON.stringify({ v: 1, t: j.t, f: j.f || [], c: j.c || {}, r: j.r || {}, l: j.l || "medium", s: j.s || 0, ts: j.ts || Date.now() }));
    }
    var Pl = readLS(PK);
    if (j.p && typeof j.p.xp === "number" && (!Pl || (j.p.ts || 0) > (Pl.ts || 0))) {
      rawSet.call(window.localStorage, PK, JSON.stringify(j.p));
    }
  }

  async function init() {
    if (!FS) {
      status("ok", "Saved in this browser", "", "Not running as the Android app, so data stays in this browser.");
      return;
    }
    status("idle", "Starting", "", "");
    try { if (FS.requestPermissions) await FS.requestPermissions(); } catch (e) {}
    dir = "DOCUMENTS";
    try { await ensure("DOCUMENTS"); }
    catch (e) {
      dir = "DATA";
      try { await ensure("DATA"); } catch (e2) { dir = null; }
    }
    if (!dir) { status("err", "Not saved", "", "Couldn't open any storage folder."); return; }
    var txt = await readFile(dir);
    if (txt === null && dir === "DOCUMENTS") txt = await readFile("DATA");
    if (txt) { seed(txt); fileHasData = hasData(txt); }
    await flush(true);                    // creates the data file on first launch
  }

  /* ---------- Android back button ---------- */
  function curPage() {
    var a = ["play", "bank", "review", "list", "progress"];
    for (var i = 0; i < a.length; i++) { var e = document.getElementById("pg-" + a[i]); if (e && !e.hidden) return a[i]; }
    return "play";
  }
  var lastBack = 0;
  function exitTap() {
    var now = Date.now();
    if (now - lastBack < 2000) { if (APP && APP.exitApp) APP.exitApp(); return; }
    lastBack = now;
    try { toast("Press back again to exit", "info"); } catch (e) {}
  }
  function onBack() {
    try {
      var pk = document.getElementById("pkp");
      if (pk && !pk.hidden) { document.body.click(); return; }            // close scope picker
      var mn = document.querySelector(".mn");
      if (mn && mn.open) { mn.open = false; return; }                     // close the ⋯ menu
      var pg = curPage();
      if (pg === "play") {
        var c = document.getElementById("card");
        if (c && c.querySelector(".end")) { hub(); return; }              // finished screen -> runs
        if (typeof run !== "undefined" && run) { endRun(); return; }      // in a run -> asks "End this run?"
        exitTap(); return;                                                // on the runs screen
      }
      if (pg === "bank") {
        var N = window.__nv;
        if (window.__fnw) { window.__fnw = false; fdraw(); return; }
        if (N && N.f) { N.f = fpar(N.f) || null; fdraw(); return; }       // up one folder
        if (N && N.c) { N.c = null; fdraw(); return; }                    // up to the categories
        go("play"); return;
      }
      if (pg === "review" && typeof rv !== "undefined" && rv.ed) { rv.ed = null; rvDraw(); return; }
      go("play");
    } catch (e) { exitTap(); }
  }

  window.RR = {
    native: native,
    afterStart: function () { if (APP && APP.addListener) APP.addListener("backButton", onBack); },
    _onBack: onBack
  };

  /* ---------- lifecycle + start ---------- */
  document.addEventListener("visibilitychange", function () { if (document.hidden) flush(false); });
  if (APP && APP.addListener) { try { APP.addListener("pause", function () { flush(false); }); } catch (e) {} }
  var chip = document.getElementById("sv");
  if (chip) chip.addEventListener("click", function () { if (FS) flush(true); });

  init().catch(function (e) { showErr(e); }).then(function () { if (window.__rrStart) window.__rrStart(); });
})();
