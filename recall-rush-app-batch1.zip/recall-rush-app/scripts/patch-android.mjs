// Run once after `cap add android`. Lets the app write to the shared Documents folder.
// Safe to run again: it skips anything already patched.
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const file = process.argv[2] || join(root, "android", "app", "src", "main", "AndroidManifest.xml");
if (!existsSync(file)) { console.error("AndroidManifest.xml not found: " + file + "\nRun `npx cap add android` first."); process.exit(1); }

let x = readFileSync(file, "utf8");
let changed = false;

const perms = [
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
];
for (const p of perms) {
  const name = p.match(/android:name="([^"]+)"/)[1];
  if (!x.includes(name)) {
    x = x.replace("</manifest>", "    " + p + "\n</manifest>");
    changed = true;
  }
}
if (!x.includes("requestLegacyExternalStorage")) {
  if (!/<application\b/.test(x)) { console.error("No <application> tag found."); process.exit(1); }
  x = x.replace(/<application\b/, '<application\n        android:requestLegacyExternalStorage="true"');
  changed = true;
}

if (changed) { writeFileSync(file, x); console.log("AndroidManifest.xml patched."); }
else console.log("AndroidManifest.xml already patched.");
